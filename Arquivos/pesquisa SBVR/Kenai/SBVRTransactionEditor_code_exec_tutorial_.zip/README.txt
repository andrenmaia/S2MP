SBVRthe TransactionEditor (code+jar+example files)

in the zip file you can find:
-SBVRTransactionEditor.jar (a runnable jar file )

-SBVRTransactionEditor.bat and SBVRTransactionEditor.sh  (scripts to launch the application)
-ServiceDirectory folder (temporary folder: it contains the WSDL files. useful until a web services registry is implemented )
-example_Rules.txt (example of supported rules)
-QuickStart tutorial

to run the application extract the following files in a folder on your computer:
-SBVRTransactionEditor.jar
-ServiceDirectory
-SBVRTransactionEditor.bat
-SBVRTransactionEditor.sh  
-ServiceDirectory folder (necessary!)
run the SBVRTransactionEditor.bat (on windows) or the SBVRTransactionEditor.sh (on linux) 