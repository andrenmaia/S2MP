#!/bin/sh
#quick launch
java -jar SBVRTransactionEditor.jar
